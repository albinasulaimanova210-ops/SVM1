import matplotlib.pyplot as plt
import numpy as np


X = np.array([[1, 1], [2, 1.5], [1.5, 2], [5, 5], [6, 5.5], [5.5, 6]])
y = np.array([-1, -1, -1, 1, 1, 1])

plt.scatter(X[:, 0], X[:, 1], c=y, cmap='bwr', s=100, edgecolors='k')


ax = plt.gca()
xlim = ax.get_xlim()
ylim = ax.get_ylim()

xx = np.linspace(xlim[0], xlim[1], 30)
yy = np.linspace(ylim[0], ylim[1], 30)
YY, XX = np.meshgrid(yy, xx)
xy = np.vstack([XX.ravel(), YY.ravel()]).T


Z = 0.5 * XX + 0.5 * YY - 3.5 
ax.contour(XX, YY, Z.reshape(XX.shape), colors='k', levels=[-1, 0, 1], alpha=0.5, linestyles=['--', '-', '--'])

plt.title("Maksimum Marjin (Güvenlik Koridoru)")
plt.xlabel("X Koordinatı")
plt.ylabel("Y Koordinatı")
plt.show()